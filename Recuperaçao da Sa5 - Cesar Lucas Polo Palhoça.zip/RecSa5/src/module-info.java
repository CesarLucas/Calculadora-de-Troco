/**
 * 
 */
/**
 * 
 */
module RecSa5 {
	requires java.sql;
}